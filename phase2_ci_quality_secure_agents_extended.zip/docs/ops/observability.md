# Observability
Emit structured logs:
- policy.verify: { agent, issues, overrides_applied }
- artifacts.verify: { trace_id, sha_ok, size_ok }
Metrics to track:
- qa_block_rate, triage_latency_ms, pr_merged_rate
