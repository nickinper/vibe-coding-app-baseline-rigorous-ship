# Net Allowlist UI (Desktop)
Run:
```
UI_ADMIN_TOKEN=<secret> PORT=5173 node scripts/net-allowlist-ui.js
```
Then call:
```
curl -H "X-ADMIN-TOKEN: <secret>" http://localhost:5173/config
```
