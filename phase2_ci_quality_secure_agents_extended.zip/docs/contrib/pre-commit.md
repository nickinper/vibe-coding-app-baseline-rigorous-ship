# Pre-Commit Setup
Enable repo-local hooks:
```
git config core.hooksPath .githooks
```
